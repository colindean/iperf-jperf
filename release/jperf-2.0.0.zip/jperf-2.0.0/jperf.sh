#!/bin/sh

java -classpath jperf-2.0.0.jar:lib/forms-1.1.0.jar:lib/jcommon-1.0.10.jar:lib/jfreechart-1.0.6.jar:lib/swingx-2008_02_03.jar net.nlanr.jperf.JPerf
